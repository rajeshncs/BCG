$(function () {
  // Slideshow 1
  $("#slider1").responsiveSlides({
    speed: 800
  });

  // Slideshow 4
  $("#slider4").responsiveSlides({
    auto: false,
    pager: false,
    nav: true,
    speed: 500,
    namespace: "callbacks",
    before: function () {
      $('.events').append("<li>before event fired.</li>");
    },
    after: function () {
      $('.events').append("<li>after event fired.</li>");
    }
  });

  $("#page2slider2").responsiveSlides({
    auto: false,
    pager: false,
    nav: true,
    speed: 500,
    namespace: "callbacks",
    before: function () {
      $('.events').append("<li>before event fired.</li>");
    },
    after: function () {
      $('.events').append("<li>after event fired.</li>");
    }
  });

  $("#page2slider3").responsiveSlides({
    auto: false,
    pager: false,
    nav: true,
    speed: 500,
    namespace: "callbacks",
    before: function () {
      $('.events').append("<li>before event fired.</li>");
    },
    after: function () {
      $('.events').append("<li>after event fired.</li>");
    }
  });

  $(".approach-content .scroll-btn").click(function(e) {
    	var incr = 0;
      incr += 150;
      var x = $(".approach-content .scroll-more").scrollTop() + incr;
      $(".approach-content .scroll-more").animate({ scrollTop: x }, 500);
  });

  $(".challenge-left .scroll-btn").click(function(e) {
      var incr = 0;
      incr += 150;
      var x = $(".challenge-left .scroll-more").scrollTop() + incr;
      $(".challenge-left .scroll-more").animate({ scrollTop: x }, 600);
  });

  $(".down-arrow").click(function(e) {
    $("html, body").animate({ scrollTop: 700 /* $(document).height() */ }, 1000);
  });

});
